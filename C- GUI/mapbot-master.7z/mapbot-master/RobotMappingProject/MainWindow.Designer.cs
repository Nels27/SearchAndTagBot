﻿namespace RobotMappingProject
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mbedData = new System.IO.Ports.SerialPort(this.components);
            this.portBox = new System.Windows.Forms.ComboBox();
            this.portButton = new System.Windows.Forms.Button();
            this.errorBox = new System.Windows.Forms.TextBox();
            this.testData = new System.Windows.Forms.Button();
            this.X = new System.Windows.Forms.Button();
            this.mapImage = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // portBox
            // 
            this.portBox.FormattingEnabled = true;
            this.portBox.Location = new System.Drawing.Point(1139, 68);
            this.portBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.portBox.Name = "portBox";
            this.portBox.Size = new System.Drawing.Size(92, 21);
            this.portBox.TabIndex = 0;
            this.portBox.MouseEnter += new System.EventHandler(this.portBox_MouseEnter);
            // 
            // portButton
            // 
            this.portButton.Location = new System.Drawing.Point(1139, 92);
            this.portButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.portButton.Name = "portButton";
            this.portButton.Size = new System.Drawing.Size(91, 28);
            this.portButton.TabIndex = 3;
            this.portButton.Text = "Select COM Port";
            this.portButton.UseVisualStyleBackColor = true;
            this.portButton.Click += new System.EventHandler(this.portButton_Click);
            // 
            // errorBox
            // 
            this.errorBox.Location = new System.Drawing.Point(1139, 125);
            this.errorBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.errorBox.Multiline = true;
            this.errorBox.Name = "errorBox";
            this.errorBox.Size = new System.Drawing.Size(92, 53);
            this.errorBox.TabIndex = 4;
            // 
            // testData
            // 
            this.testData.Location = new System.Drawing.Point(1139, 182);
            this.testData.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.testData.Name = "testData";
            this.testData.Size = new System.Drawing.Size(91, 26);
            this.testData.TabIndex = 5;
            this.testData.Text = "Test Sending Data";
            this.testData.UseVisualStyleBackColor = true;
            this.testData.MouseClick += new System.Windows.Forms.MouseEventHandler(this.testData_MouseClick);
            // 
            // X
            // 
            this.X.Location = new System.Drawing.Point(829, 447);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(37, 23);
            this.X.TabIndex = 7;
            this.X.Text = "X";
            this.X.UseVisualStyleBackColor = true;
            this.X.Click += new System.EventHandler(this.X_Click);
            // 
            // mapImage
            // 
            this.mapImage.BackgroundImage = global::RobotMappingProject.Properties.Resources.grid;
            this.mapImage.Location = new System.Drawing.Point(0, 0);
            this.mapImage.Margin = new System.Windows.Forms.Padding(2);
            this.mapImage.Name = "mapImage";
            this.mapImage.Size = new System.Drawing.Size(600, 600);
            this.mapImage.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(706, 545);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(706, 578);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(706, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(706, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(706, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "label5";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1474, 668);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.X);
            this.Controls.Add(this.mapImage);
            this.Controls.Add(this.testData);
            this.Controls.Add(this.errorBox);
            this.Controls.Add(this.portButton);
            this.Controls.Add(this.portBox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "MainWindow";
            this.Text = "Mapping Project";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox portBox;
        private System.Windows.Forms.Button portButton;
        private System.Windows.Forms.TextBox errorBox;
        private System.Windows.Forms.Button testData;
        private System.Windows.Forms.Panel mapImage;
        internal System.IO.Ports.SerialPort mbedData;
        private System.Windows.Forms.Button X;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

