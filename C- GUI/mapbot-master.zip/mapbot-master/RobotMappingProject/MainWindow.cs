﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RobotMappingProject
{
    public partial class MainWindow : Form
    {



        //will write over these values as we move
        int x1;
        int y1;


        int counter = 0;
        int c = 0;
        string heading_str;
        string time_str;
        string tag_str;

        string heading_old;
        string time_old;
        string tag_old;

        private void getValues()
        {
            string path = "C:\\Users/efuller3/Documents/mapdata.txt";
            StreamReader sr = new StreamReader(path);
            string line = sr.ReadLine();
            string[] values = line.Split(',');



            heading_str = values[c];
            c++;
            time_str = values[c];
            c++;
            tag_str = values[c];
            c++;
        }

        private void setOldValues()
        {

            heading_old = heading_str;
            time_old = time_str;
            tag_old = tag_str;
        }

        private void X_Click(object sender, EventArgs e)
        {
            getValues();

            label3.Text = heading_str;
            label4.Text = time_str;
            label5.Text = tag_str;

            Label drop = new Label();
            drop.Width = 14;
            drop.ForeColor = Color.Red;
            drop.BackColor = Color.White;
            drop.Text = "X";

            //only want to run calculations if the heading or time variable changes, if only tag string changes then, ONLY place label
            if (heading_str == heading_old & time_str == time_old & tag_str == "0")
            {
                label11.Text = "did nothing";
                //do nothing if all the new values are the same as the old aka it was a duplicate input on the SD
            }
            //if the heading or time has changed need to update the location
            else if (heading_str != heading_old | time_str != time_old)
            {
                label11.Text = "update1";
                //(0,0) is the upper left hand corner and boxes will be anchored by corner of box, not center
                int x_start = 300;
                int y_start = 300;

                //get the time and heading from pi
                double time = Convert.ToDouble(time_str); //seconds
                double heading = Convert.ToDouble(heading_str); //degrees
                double trig_h = 90 - heading;
                if (trig_h < 0)
                    trig_h = 360 + trig_h;
                //constant speed calculated (inch/second)
                double speed = 4.470721;
                //scaling of map (600,600)px to (8x8)ft
                double scale = 75 / 12;

                //calculations
                double distance = time * speed;

                double doub_x = Math.Abs(distance * Math.Cos(trig_h) * scale);
                //label1.Text = Convert.ToString(doub_x);
                double doub_y = Math.Abs(distance * Math.Sin(trig_h) * scale);
                //label2.Text = Convert.ToString(doub_y);
                int new_x = Convert.ToInt32(doub_x);
                int new_y = Convert.ToInt32(doub_y);
                int h = Convert.ToInt32(heading);




                if (counter == 0)   //special condition if it is the first location
                    {
                        if (h < 90 & h > 0)
                        {
                            drop.Location = new Point(x: x_start + new_x, y: y_start - new_y);
                            x1 = x_start + new_x;
                            y1 = y_start - new_y;
                            counter++;
                        }
                        else if (h > 90 & h < 180)
                        {
                            drop.Location = new Point(x: x_start + new_x, y: y_start + new_y);
                            x1 = x_start + new_x;
                            y1 = y_start + new_y;
                            counter++;
                        }
                        else if (h < 270 & h > 180)
                        {
                            drop.Location = new Point(x: x_start - new_x, y: y_start + new_y);
                            x1 = x_start - new_x;
                            y1 = y_start + new_y;
                            counter++;
                        }
                        else if (h < 360 & h > 270)
                        {
                            drop.Location = new Point(x: x_start - new_x, y: y_start - new_y);
                            x1 = x_start - new_x;
                            y1 = y_start - new_y;
                            counter++;
                        }

                    }
                    else
                    {
                        if (h < 90 & h > 0)
                        {
                            drop.Location = new Point(x: x_start + new_x, y: y_start - new_y);
                            x1 = x_start + new_x;
                            y1 = y_start - new_y;
                            counter++;
                        }
                        else if (h > 90 & h < 180)
                        {
                            drop.Location = new Point(x: x_start + new_x, y: y_start + new_y);
                            x1 = x_start + new_x;
                            y1 = y_start + new_y;
                            counter++;
                        }
                        else if (h < 270 & h > 180)
                        {
                            drop.Location = new Point(x: x_start - new_x, y: y_start + new_y);
                            x1 = x_start - new_x;
                            y1 = y_start + new_y;
                            counter++;
                        }
                        else if (h < 360 & h > 270)
                        {
                            drop.Location = new Point(x: x_start - new_x, y: y_start - new_y);
                            x1 = x_start - new_x;
                            y1 = y_start - new_y;
                            counter++;
                        }
                    }
                //place it on the map

                    if (tag_str == "1")
                    {
     
                        mapImage.Controls.Add(drop);
                    

                    }
                    else if (tag_str == "0")
                    {
                        drop.ForeColor = Color.Blue;
                        mapImage.Controls.Add(drop);


                    }

                label1.Text = Convert.ToString(x1);
                label2.Text = Convert.ToString(y1);
                setOldValues();
                

            }
            //if the only values that changes is the tag bool, drop the X
            else if(heading_str == heading_old & time_str == time_old & tag_str == "1")
            {
                label11.Text = "update2";
                drop.Location = new Point(x:x1, y:y1);
                mapImage.Controls.Add(drop);
                label1.Text = Convert.ToString(x1);
                label2.Text = Convert.ToString(y1);
                
            }
        }

        
        public MainWindow()
        {
            InitializeComponent();
            //CheckForIllegalCrossThreadCalls = false;
            
        }



    }
}
