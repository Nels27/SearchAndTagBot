﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RobotMappingProject
{
    public partial class MainWindow : Form
    { 
        //will write over these values as we move
        int x_stop;
        int y_stop;

        //(0,0) is the upper left hand corner and boxes will be anchored by corner of box, not center
        int x_start = 300;
        int y_start = 300;

        int c = 0;
        string heading_str;
        string time_str;
        string tag_str;

        string heading_old;
        string time_old;
        string tag_old;
        public bool status = false;

        Point first;
        Point second;

        private void getValues()
        {
            //string path = "E:\\mapdata.txt";
            string path = "C:\\Users/efuller3/Documents/mapdata.txt";
            StreamReader sr = new StreamReader(path);
            string line = sr.ReadLine();
            string[] values = line.Split(',');

           
            
                heading_str = values[c];
                c++;
                time_str = values[c];
                c++;
                tag_str = values[c];
                c++;

                label14.Text = Convert.ToString(c/3);
            


        }

        private void setOldValues()
        {
            //new start position is old stop position
            x_start = x_stop;
            y_start = y_stop;

            heading_old = heading_str;
            time_old = time_str;
            tag_old = tag_str;

            second = first;

            label19.Text = Convert.ToString(y_stop);
            label20.Text = Convert.ToString(x_stop);
        }




        private void X_Click(object sender, EventArgs e)
        {
            getValues();

            

            
            if (label14.Text == "1")
            {

                Label center = new Label();
                center.Width = 14;
                center.ForeColor = Color.Black;
                center.BackColor = Color.Transparent;
                center.Text = "X";
                center.Location = new Point(x: x_start-7, y: y_start-7);
                mapImage.Controls.Add(center);
            }


            label3.Text = heading_str;
            label4.Text = time_str;
            label5.Text = tag_str;

            label27.Text = heading_old;
            label26.Text = time_old;
            label25.Text = tag_old;

            Label drop = new Label();
            drop.Width = 14;
            drop.ForeColor = Color.Red;
            drop.BackColor = Color.Transparent;
            drop.Text = "X";//label14.Text;

            Label circle = new Label();
            circle.Width = 14;
            circle.ForeColor = Color.Blue;
            circle.BackColor = Color.Transparent;
            circle.Text = "O";//label14.Text;

            //only want to run calculations if the heading or time variable changes, if only tag string changes then, ONLY place label
            if (heading_str == heading_old & time_str == time_old & tag_str == tag_old)
            {
                label11.Text = "On Standby";
                //do nothing if all the new values are the same as the old aka it was a duplicate input on the SD
            }
            //if the heading or time has changed need to update the locationm
            else if (heading_str != heading_old | time_str != time_old)
            {
                //label11.Text = "update1";


                //get the time and heading from pi
                double time = Convert.ToDouble(time_str); //seconds
                double heading = Convert.ToDouble(heading_str); //degrees
                double trig_h = 90 - heading;
                if (trig_h < 0)
                    trig_h = 360 + trig_h;
                //constant speed calculated (inch/second)
                double speed = 4.470721;
                //scaling of map (600,600)px to (8x8)ft
                double scale = 75 / 12;

                //calculations
                double distance = time * speed;

                double doub_x = Math.Abs(distance * Math.Cos(trig_h));// * scale);
                //label1.Text = Convert.ToString(doub_x);
                double doub_y = Math.Abs(distance * Math.Sin(trig_h));// * scale);
                //label2.Text = Convert.ToString(doub_y);
                int new_x = Convert.ToInt32(doub_x);
                int new_y = Convert.ToInt32(doub_y);
                int h = Convert.ToInt32(heading);


                if (h < 90 & h > 0)
                {
                    drop.Location = new Point(x: x_start + new_x, y: y_start - new_y);
                    circle.Location = drop.Location;
                    x_stop = x_start + new_x;
                    y_stop = y_start - new_y;
                   
                }
                else if (h > 90 & h < 180)
                {
                    drop.Location = new Point(x: x_start + new_x, y: y_start + new_y);
                    first = drop.Location;
                    circle.Location = drop.Location;
                    x_stop = x_start + new_x;
                    y_stop = y_start + new_y;
                    
                }
                else if (h < 270 & h > 180)
                {
                    drop.Location = new Point(x: x_start - new_x, y: y_start + new_y);
                    first = drop.Location;
                    circle.Location = drop.Location;
                    x_stop = x_start - new_x;
                    y_stop = y_start + new_y;
                    
                }
                else if (h < 360 & h > 270)
                {
                    drop.Location = new Point(x: x_start - new_x, y: y_start - new_y);
                    first = drop.Location;
                    circle.Location = drop.Location;
                    x_stop = x_start - new_x;
                    y_stop = y_start - new_y;
                   
                }




                //place it on the map

                if (tag_str == "1")
                {
                    mapImage.Controls.Add(drop);
                    drop.Name = "pin" + label14.Text;
                    label21.Text = "the name of this point is:" + drop.Name;
                    label11.Text = "Robot moved and found a threat";


                }
                else if (tag_str == "0")
                {

                    mapImage.Controls.Add(circle);
                   
                    circle.Name = "pin" + label14.Text;
                    label21.Text = "the name of this point is:" + circle.Name;
                    label11.Text = "Robot moved and found a friendly object";


                }
                else if (tag_str == "m")
                {
                    label11.Text = "Robot moved and did not detect an object";

                }

                label1.Text = Convert.ToString(x_stop);
                label2.Text = Convert.ToString(y_stop);
                setOldValues();


          


            }
            
            //if the only values that changes is the tag bool, drop the X
            else if(heading_str == heading_old && time_str == time_old && (tag_str == "1" | tag_str == "0"))
            {
                label11.Text = "Tagging at current location";
                if (tag_str == "1")
                {
                    drop.Location = new Point(x: x_stop, y: y_stop);
                    mapImage.Controls.Add(drop);
                    label1.Text = Convert.ToString(x_stop);
                    label2.Text = Convert.ToString(y_stop);
                    int num = Convert.ToInt32(label14.Text);
                    var labelToRemove = mapImage.Controls["pin" + Convert.ToString(num - 1)];
                    mapImage.Controls.Remove(labelToRemove);

                    mapImage.Controls.Add(drop);
                    drop.Name = "pin" + label14.Text;
                    label21.Text = "the name of this point is:" + drop.Name;
                }
                else if (tag_str == "0")
                {
                    circle.Location = new Point(x: x_stop, y: y_stop);
                    mapImage.Controls.Add(circle);
                    label1.Text = Convert.ToString(x_stop);
                    label2.Text = Convert.ToString(y_stop);
                    int num = Convert.ToInt32(label14.Text);
                    var labelToRemove = mapImage.Controls["pin" + Convert.ToString(num - 1)];
                    mapImage.Controls.Remove(labelToRemove);

                    mapImage.Controls.Add(circle);
                    drop.Name = "pin" + label14.Text;
                    label21.Text = "the name of this point is:" + circle.Name;
                }
            }
        }

        
        public MainWindow()
        {
            InitializeComponent();
            //CheckForIllegalCrossThreadCalls = false;
            
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {

        }

      
    }
}
